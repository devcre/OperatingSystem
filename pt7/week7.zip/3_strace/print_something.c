#include <stdio.h>
void main(){
	char c = 'A';
	putchar(c);
	return;
}



